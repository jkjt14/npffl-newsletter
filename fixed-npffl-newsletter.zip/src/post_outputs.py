from __future__ import annotations

def maybe_post_to_slack(path_md: str) -> None:
    # Stub: integrate Slack webhook if desired
    return
